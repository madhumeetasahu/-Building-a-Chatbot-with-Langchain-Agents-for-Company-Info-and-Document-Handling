<!-- chatbot_app/templates/index.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add your head content here -->
</head>
<body>
    <h1>Langchain Chatbot</h1>
    <form method="post" action="{% url 'handle_user_input' %}">
        {% csrf_token %}
        <label for="user_input">User Input:</label>
        <input type="text" name="user_input" required>
        <button type="submit">Submit</button>
    </form>
    {% if response %}
        <p>Response: {{ response }}</p>
    {% endif %}
</body>
</html>
