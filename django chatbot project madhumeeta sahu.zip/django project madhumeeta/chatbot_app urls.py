# chatbot_app/urls.py
from django.urls import path
from .views import index, handle_user_input

urlpatterns = [
    path('', index, name='index'),
    path('handle_user_input/', handle_user_input, name='handle_user_input'),
]
