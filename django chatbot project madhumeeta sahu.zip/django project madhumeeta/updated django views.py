# chatbot_app/views.py
from django.shortcuts import render
from .langchain_api import LangchainAPI
from langchain_agents.company_info_agent import CompanyInfoAgent
from langchain_agents.document_handler_agent import DocumentHandlerAgent

def index(request):
    return render(request, 'index.html')

def handle_user_input(request):
    user_input = request.POST.get('user_input')
    
    # Use Langchain to analyze user input and determine intent
    intent = LangchainAPI.analyze_intent(user_input)

    if intent == "company_info":
        company_info_agent = CompanyInfoAgent()
        response = company_info_agent.get_company_info()
    elif intent == "upload_document":
        # Assume file_type and file_content are obtained from the request
        file_type = request.POST.get('file_type')
        file_content = request.FILES['file_content'].read()
        
        document_handler_agent = DocumentHandlerAgent()
        response = document_handler_agent.handle_document_upload(file_type, file_content)
    else:
        response = "I'm sorry, I didn't understand that request."

    return render(request, 'index.html', {'response': response})
