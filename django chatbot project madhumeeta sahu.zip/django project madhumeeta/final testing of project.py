python manage.py runserver
